import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  json,
  mysqlEnum,
} from "drizzle-orm/mysql-core";

export const prototypes = mysqlTable("prototypes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  gameType: varchar("game_type", { length: 100 }).notNull(),
  keywords: varchar("keywords", { length: 500 }).notNull(),
  status: mysqlEnum("status", ["generating", "completed", "error"]).notNull().default("generating"),
  coreLogic: text("core_logic"),
  interactionFlow: text("interaction_flow"),
  numericalFramework: text("numerical_framework"),
  validationResult: text("validation_result"),
  flowchartMermaid: text("flowchart_mermaid"),
  documentMarkdown: text("document_markdown"),
  uiPrototype: json("ui_prototype"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

export type Prototype = typeof prototypes.$inferSelect;
export type NewPrototype = typeof prototypes.$inferInsert;
