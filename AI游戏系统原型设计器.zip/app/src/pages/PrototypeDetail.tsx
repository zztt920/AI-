import { useParams, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import FlowchartViewer from "@/components/FlowchartViewer";
import UIPrototypeViewer from "@/components/UIPrototypeViewer";
import {
  ArrowLeft,
  FileText,
  GitBranch,
  Shield,
  Layers,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  XCircle,
} from "lucide-react";

export default function PrototypeDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const prototypeId = Number(id);

  const { data: proto, isLoading } = trpc.prototype.get.useQuery(
    { id: prototypeId },
    { enabled: !!prototypeId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="max-w-5xl mx-auto space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!proto) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <XCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
          <h2 className="text-xl font-semibold text-slate-800">原型不存在</h2>
          <p className="text-slate-500 mt-1 mb-4">
            该原型可能已被删除或ID无效
          </p>
          <Button onClick={() => navigate("/")} variant="outline">
            返回首页
          </Button>
        </div>
      </div>
    );
  }

  const statusConfig = {
    generating: { label: "生成中", color: "bg-yellow-100 text-yellow-700" },
    completed: { label: "已完成", color: "bg-green-100 text-green-700" },
    error: { label: "失败", color: "bg-red-100 text-red-700" },
  };

  const status = statusConfig[proto.status as keyof typeof statusConfig];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/")}
              className="gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <Separator orientation="vertical" className="h-5" />
            <h1 className="text-sm font-semibold text-slate-800 truncate max-w-md">
              {proto.title}
            </h1>
            <Badge className={status.color}>{status.label}</Badge>
          </div>
          <div className="text-xs text-slate-400">
            {proto.createdAt
              ? new Date(proto.createdAt).toLocaleString("zh-CN")
              : ""}
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 py-6">
        {/* Meta Info */}
        <Card className="mb-6 border-slate-200">
          <CardContent className="py-3 flex flex-wrap gap-4 text-sm">
            <div>
              <span className="text-slate-400">游戏类型：</span>
              <span className="font-medium">{proto.gameType}</span>
            </div>
            <div>
              <span className="text-slate-400">关键词：</span>
              <span className="font-medium">{proto.keywords}</span>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="logic" className="space-y-4">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="logic" className="gap-1.5">
              <FileText className="w-3.5 h-3.5" />
              核心逻辑
            </TabsTrigger>
            <TabsTrigger value="flow" className="gap-1.5">
              <GitBranch className="w-3.5 h-3.5" />
              交互流程
            </TabsTrigger>
            <TabsTrigger value="numbers" className="gap-1.5">
              <BarChart3 className="w-3.5 h-3.5" />
              数值框架
            </TabsTrigger>
            <TabsTrigger value="flowchart" className="gap-1.5">
              <GitBranch className="w-3.5 h-3.5" />
              流程图
            </TabsTrigger>
            <TabsTrigger value="ui" className="gap-1.5">
              <Layers className="w-3.5 h-3.5" />
              UI 原型
            </TabsTrigger>
            <TabsTrigger value="validation" className="gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              逻辑校验
            </TabsTrigger>
          </TabsList>

          {/* Core Logic */}
          <TabsContent value="logic">
            <DocCard
              title="核心逻辑文档"
              icon={<FileText className="w-5 h-5 text-indigo-500" />}
              content={proto.coreLogic}
            />
          </TabsContent>

          {/* Interaction Flow */}
          <TabsContent value="flow">
            <DocCard
              title="交互流程文档"
              icon={<GitBranch className="w-5 h-5 text-emerald-500" />}
              content={proto.interactionFlow}
            />
          </TabsContent>

          {/* Numerical Framework */}
          <TabsContent value="numbers">
            <DocCard
              title="数值框架文档"
              icon={<BarChart3 className="w-5 h-5 text-orange-500" />}
              content={proto.numericalFramework}
            />
          </TabsContent>

          {/* Flowchart */}
          <TabsContent value="flowchart">
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <GitBranch className="w-5 h-5 text-purple-500" />
                  系统流程图
                </CardTitle>
              </CardHeader>
              <CardContent>
                {proto.flowchartMermaid ? (
                  <FlowchartViewer chart={proto.flowchartMermaid} />
                ) : (
                  <div className="text-center py-12 text-slate-400">
                    暂无流程图数据
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* UI Prototype */}
          <TabsContent value="ui">
            {proto.uiPrototype ? (
              <UIPrototypeViewer screens={(proto.uiPrototype as Record<string, unknown>).screens as Array<Record<string, unknown>> || []} />
            ) : (
              <Card className="border-slate-200">
                <CardContent className="text-center py-12 text-slate-400">
                  暂无UI原型数据
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Validation */}
          <TabsContent value="validation">
            <ValidationView content={proto.validationResult} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function DocCard({
  title,
  icon,
  content,
}: {
  title: string;
  icon: React.ReactNode;
  content: string | null;
}) {
  return (
    <Card className="border-slate-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          {icon}
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {content ? (
          <div className="prose prose-slate prose-sm max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
        ) : (
          <div className="text-center py-12 text-slate-400">暂无数据</div>
        )}
      </CardContent>
    </Card>
  );
}

function ValidationView({ content }: { content: string | null }) {
  if (!content) {
    return (
      <Card className="border-slate-200">
        <CardContent className="text-center py-12 text-slate-400">
          暂无校验结果
        </CardContent>
      </Card>
    );
  }

  // Parse severity indicators
  const hasErrors = content.includes("不通过") || content.includes("error");
  const hasWarnings = content.includes("警告") || content.includes("warning");

  return (
    <div className="space-y-4">
      {/* Status Banner */}
      <div
        className={`rounded-lg border p-4 flex items-center gap-3 ${
          hasErrors
            ? "bg-red-50 border-red-200"
            : hasWarnings
            ? "bg-yellow-50 border-yellow-200"
            : "bg-green-50 border-green-200"
        }`}
      >
        {hasErrors ? (
          <XCircle className="w-6 h-6 text-red-500" />
        ) : hasWarnings ? (
          <AlertTriangle className="w-6 h-6 text-yellow-500" />
        ) : (
          <CheckCircle className="w-6 h-6 text-green-500" />
        )}
        <div>
          <div className="font-semibold text-sm">
            {hasErrors
              ? "校验不通过，发现严重问题"
              : hasWarnings
              ? "校验通过，存在警告"
              : "校验通过，无严重问题"}
          </div>
          <div className="text-xs text-slate-500">
            {hasErrors
              ? "建议修复错误后重新生成"
              : hasWarnings
              ? "建议关注警告项并优化"
              : "系统设计合理，可以继续开发"}
          </div>
        </div>
      </div>

      {/* Content */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="w-5 h-5 text-red-500" />
            逻辑校验报告
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="prose prose-slate prose-sm max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
