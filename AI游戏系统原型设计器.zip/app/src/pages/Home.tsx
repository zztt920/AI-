import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Loader2,
  Wand2,
  FileText,
  History,
  Sparkles,
  Shield,
  GitBranch,
  Layers,
} from "lucide-react";

const GAME_TYPES = [
  "角色扮演（RPG）",
  "动作游戏（ACT）",
  "策略游戏（SLG）",
  "MMORPG",
  "卡牌游戏",
  "Roguelike",
  "模拟经营",
  "休闲益智",
  "其他",
];

export default function Home() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [gameType, setGameType] = useState("");
  const [keywords, setKeywords] = useState("");
  const [requirements, setRequirements] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const createMutation = trpc.prototype.create.useMutation();
  const generateMutation = trpc.ai.generatePrototype.useMutation();

  const handleGenerate = async () => {
    if (!title || !gameType || !keywords) return;
    setIsGenerating(true);
    try {
      const created = await createMutation.mutateAsync({
        title,
        gameType,
        keywords,
      });

      await generateMutation.mutateAsync({
        id: created.id,
        title,
        gameType,
        keywords,
        requirements: requirements || undefined,
      });

      navigate(`/prototype/${created.id}`);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const canGenerate = title && gameType && keywords && !isGenerating;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-indigo-600" />
            <h1 className="text-lg font-bold text-slate-800">
              AI 游戏系统原型设计器
            </h1>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/history")}
            className="gap-1.5"
          >
            <History className="w-4 h-4" />
            历史记录
          </Button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Hero */}
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-slate-900 mb-3">
            输入游戏创意，AI 自动生成系统设计原型
          </h2>
          <p className="text-slate-500 max-w-2xl mx-auto">
            基于 GPT 智能解析需求，自动生成包含核心逻辑、交互流程、数值框架、
            流程图、逻辑校验和 UI 原型的完整设计文档
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { icon: Sparkles, label: "AI 需求解析", desc: "智能分析玩法关键词" },
            { icon: FileText, label: "自动文档生成", desc: "核心逻辑+交互流程" },
            { icon: GitBranch, label: "流程图生成", desc: "Mermaid 自动渲染" },
            { icon: Shield, label: "逻辑校验", desc: "状态机冲突检测" },
          ].map((f) => (
            <Card key={f.label} className="border-slate-200 bg-white/60">
              <CardContent className="pt-4 text-center">
                <f.icon className="w-8 h-8 text-indigo-500 mx-auto mb-2" />
                <div className="font-medium text-sm">{f.label}</div>
                <div className="text-xs text-slate-400 mt-0.5">{f.desc}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Input Form */}
        <Card className="max-w-3xl mx-auto border-slate-200 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              游戏系统设计需求输入
            </CardTitle>
            <CardDescription>
              填写游戏类型和核心关键词，AI 将自动生成功能设计文档（FD）
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title">
                系统名称/主题 <span className="text-red-500">*</span>
              </Label>
              <Input
                id="title"
                placeholder="例如：武侠题材角色养成系统、科幻射击游戏战斗系统..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="border-slate-300"
              />
            </div>

            {/* Game Type */}
            <div className="space-y-2">
              <Label>
                游戏类型 <span className="text-red-500">*</span>
              </Label>
              <div className="flex flex-wrap gap-2">
                {GAME_TYPES.map((type) => (
                  <Badge
                    key={type}
                    variant={gameType === type ? "default" : "outline"}
                    className="cursor-pointer text-xs px-3 py-1.5 hover:bg-slate-100 transition-colors"
                    onClick={() => setGameType(type)}
                  >
                    {type}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Keywords */}
            <div className="space-y-2">
              <Label htmlFor="keywords">
                核心玩法关键词 <span className="text-red-500">*</span>
              </Label>
              <Input
                id="keywords"
                placeholder="例如：角色养成、装备锻造、副本挑战、社交公会、PVP竞技..."
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                className="border-slate-300"
              />
              <p className="text-xs text-slate-400">
                多个关键词用逗号分隔，关键词越详细生成结果越精确
              </p>
            </div>

            {/* Requirements */}
            <div className="space-y-2">
              <Label htmlFor="requirements">补充需求描述（可选）</Label>
              <Textarea
                id="requirements"
                placeholder="详细描述系统的特殊需求、目标玩家群体、与其他系统的关联关系等..."
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                className="border-slate-300 min-h-[100px]"
              />
            </div>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={!canGenerate}
              className="w-full h-11 text-base font-medium bg-indigo-600 hover:bg-indigo-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  AI 正在生成系统原型...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  生成游戏系统原型
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Example Prompts */}
        <div className="max-w-3xl mx-auto mt-6">
          <p className="text-xs text-slate-400 mb-3">快捷示例：</p>
          <div className="flex flex-wrap gap-2">
            {[
              { t: "武侠角色养成系统", gt: "角色扮演（RPG）", k: "经脉系统、装备强化、技能树、门派选择" },
              { t: "Roguelike卡牌战斗", gt: "Roguelike", k: "卡牌构筑、遗物系统、随机事件、连击机制" },
              { t: "多人在线竞技场", gt: "动作游戏（ACT）", k: "匹配系统、排行榜、段位晋升、赛季奖励" },
              { t: "模拟经营餐厅", gt: "模拟经营", k: "菜谱研发、员工管理、顾客满意度、装修系统" },
            ].map((ex, i) => (
              <button
                key={i}
                className="text-xs bg-white border border-slate-200 rounded-full px-3 py-1.5 hover:bg-indigo-50 hover:border-indigo-200 transition-colors text-slate-600"
                onClick={() => {
                  setTitle(ex.t);
                  setGameType(ex.gt);
                  setKeywords(ex.k);
                }}
              >
                {ex.t}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
