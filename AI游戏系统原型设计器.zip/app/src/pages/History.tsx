import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  Trash2,
  FileText,
  Clock,
  Gamepad2,
  Sparkles,
} from "lucide-react";

export default function History() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const { data: prototypes, isLoading } = trpc.prototype.list.useQuery();
  const deleteMutation = trpc.prototype.delete.useMutation({
    onSuccess: () => utils.prototype.list.invalidate(),
  });

  const statusConfig = {
    generating: { label: "生成中", color: "bg-yellow-100 text-yellow-700" },
    completed: { label: "已完成", color: "bg-green-100 text-green-700" },
    error: { label: "失败", color: "bg-red-100 text-red-700" },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/")}
              className="gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" />
              返回
            </Button>
            <h1 className="text-lg font-bold text-slate-800">
              历史原型记录
            </h1>
          </div>
          <Button size="sm" onClick={() => navigate("/")} className="gap-1.5">
            <Sparkles className="w-4 h-4" />
            新建原型
          </Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : !prototypes || prototypes.length === 0 ? (
          <div className="text-center py-20">
            <FileText className="w-16 h-16 text-slate-200 mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-slate-600 mb-2">
              暂无原型记录
            </h2>
            <p className="text-slate-400 mb-6">
              还没有生成过任何游戏系统原型，开始创建你的第一个吧
            </p>
            <Button onClick={() => navigate("/")}>
              <Sparkles className="w-4 h-4 mr-2" />
              创建原型
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {prototypes.map((proto) => {
              const status =
                statusConfig[proto.status as keyof typeof statusConfig];
              return (
                <Card
                  key={proto.id}
                  className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer group"
                  onClick={() => navigate(`/prototype/${proto.id}`)}
                >
                  <CardContent className="py-4 px-5">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-1.5">
                          <Gamepad2 className="w-4 h-4 text-indigo-500" />
                          <h3 className="font-semibold text-slate-800 truncate">
                            {proto.title}
                          </h3>
                          <Badge className={status.color}>
                            {status.label}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-slate-500 ml-7">
                          <span>{proto.gameType}</span>
                          <span className="text-slate-300">|</span>
                          <span className="truncate max-w-md">
                            {proto.keywords}
                          </span>
                          <span className="text-slate-300">|</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {proto.createdAt
                              ? new Date(proto.createdAt).toLocaleString(
                                  "zh-CN"
                                )
                              : ""}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (
                              confirm("确定删除此原型？此操作不可撤销。")
                            ) {
                              deleteMutation.mutate({ id: proto.id });
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs"
                        >
                          查看详情
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
