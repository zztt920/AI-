import { Routes, Route } from "react-router";
import Home from "./pages/Home";
import PrototypeDetail from "./pages/PrototypeDetail";
import History from "./pages/History";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/prototype/:id" element={<PrototypeDetail />} />
      <Route path="/history" element={<History />} />
    </Routes>
  );
}
