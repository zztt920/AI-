import { useEffect, useRef, useState } from "react";
import mermaid from "mermaid";
import { AlertTriangle, Loader2 } from "lucide-react";

interface FlowchartViewerProps {
  chart: string;
}

export default function FlowchartViewer({ chart }: FlowchartViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svg, setSvg] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!chart || !containerRef.current) return;

    const render = async () => {
      try {
        setLoading(true);
        setError(null);

        mermaid.initialize({
          startOnLoad: false,
          theme: "neutral",
          flowchart: {
            useMaxWidth: true,
            htmlLabels: true,
            curve: "basis",
            padding: 16,
          },
          themeVariables: {
            primaryColor: "#e0e7ff",
            primaryTextColor: "#1e293b",
            primaryBorderColor: "#6366f1",
            lineColor: "#64748b",
            secondaryColor: "#fef3c7",
            tertiaryColor: "#d1fae5",
          },
        });

        const id = `mermaid-${Math.random().toString(36).substring(7)}`;
        const { svg: renderedSvg } = await mermaid.render(id, chart);
        setSvg(renderedSvg);
      } catch (err) {
        console.error("Mermaid render error:", err);
        setError(
          err instanceof Error ? err.message : "流程图渲染失败，请检查语法"
        );
      } finally {
        setLoading(false);
      }
    };

    render();
  }, [chart]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-indigo-500" />
        <span className="ml-2 text-sm text-slate-500">正在渲染流程图...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-4">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-5 h-5 text-yellow-600" />
          <span className="font-medium text-sm text-yellow-800">
            流程图渲染遇到问题
          </span>
        </div>
        <p className="text-xs text-yellow-700 mb-3">{error}</p>
        <details className="text-xs">
          <summary className="cursor-pointer text-yellow-800 font-medium">
            查看原始Mermaid代码
          </summary>
          <pre className="mt-2 p-3 bg-white rounded border text-xs overflow-auto max-h-60">
            {chart}
          </pre>
        </details>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="overflow-auto flex justify-center"
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
