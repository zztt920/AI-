import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Layers,
  MousePointer,
  Type,
  Box,
  List,
  Image,
  CircleDot,
  ChevronRight,
} from "lucide-react";

interface UIElement {
  type: string;
  label: string;
  position: string;
  action?: string;
}

interface UIScreen {
  name: string;
  description: string;
  elements: UIElement[];
}

interface UIPrototypeViewerProps {
  screens: UIScreen[] | Array<Record<string, unknown>>;
}

const elementIcons: Record<string, React.ReactNode> = {
  button: <MousePointer className="w-4 h-4 text-indigo-500" />,
  label: <Type className="w-4 h-4 text-slate-500" />,
  input: <Type className="w-4 h-4 text-blue-500" />,
  list: <List className="w-4 h-4 text-emerald-500" />,
  panel: <Box className="w-4 h-4 text-orange-500" />,
  icon: <CircleDot className="w-4 h-4 text-purple-500" />,
  image: <Image className="w-4 h-4 text-pink-500" />,
  progress: <CircleDot className="w-4 h-4 text-yellow-500" />,
};

function isValidScreen(s: unknown): s is UIScreen {
  return (
    typeof s === "object" &&
    s !== null &&
    "name" in s &&
    typeof (s as Record<string, unknown>).name === "string" &&
    "elements" in s &&
    Array.isArray((s as Record<string, unknown>).elements)
  );
}

export default function UIPrototypeViewer({ screens }: UIPrototypeViewerProps) {
  const [selectedScreen, setSelectedScreen] = useState(0);

  const validScreens = (screens as unknown[]).filter(isValidScreen);

  if (!validScreens || validScreens.length === 0) {
    return (
      <Card className="border-slate-200">
        <CardContent className="text-center py-12 text-slate-400">
          暂无UI原型数据
        </CardContent>
      </Card>
    );
  }

  const screen = validScreens[selectedScreen];
  const elements = screen.elements;

  return (
    <div className="grid grid-cols-12 gap-4">
      {/* Screen List */}
      <div className="col-span-4">
        <Card className="border-slate-200 h-full">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-500" />
              界面列表 ({validScreens.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 px-2">
            <div className="space-y-1">
              {validScreens.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedScreen(idx)}
                  className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex items-center gap-2 ${
                    selectedScreen === idx
                      ? "bg-indigo-50 text-indigo-700 font-medium"
                      : "hover:bg-slate-50 text-slate-600"
                  }`}
                >
                  <ChevronRight
                    className={`w-3.5 h-3.5 ${
                      selectedScreen === idx
                        ? "text-indigo-500"
                        : "text-slate-300"
                    }`}
                  />
                  <span className="truncate">{s.name}</span>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Screen Detail */}
      <div className="col-span-8">
        <Card className="border-slate-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">{screen.name}</CardTitle>
              <Badge variant="outline" className="text-xs">
                {elements.length} 个元素
              </Badge>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {screen.description}
            </p>
          </CardHeader>
          <CardContent>
            {/* Wireframe Mockup */}
            <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 mb-4 bg-slate-50/50">
              <div className="bg-white rounded-md border shadow-sm p-4 min-h-[200px] relative">
                {/* Mock Header */}
                <div className="h-8 bg-slate-100 rounded mb-3 flex items-center px-3 gap-2">
                  <div className="w-3 h-3 rounded-full bg-slate-300" />
                  <div className="w-3 h-3 rounded-full bg-slate-300" />
                  <div className="w-3 h-3 rounded-full bg-slate-300" />
                  <div className="flex-1 text-center text-xs text-slate-400">
                    {screen.name}
                  </div>
                </div>

                {/* Mock Elements */}
                <div className="grid grid-cols-2 gap-2">
                  {elements.slice(0, 8).map((el: UIElement, idx: number) => (
                    <div
                      key={idx}
                      className="border border-slate-200 rounded p-2 flex items-center gap-2 text-xs bg-white"
                    >
                      <div className="flex-shrink-0">
                        {elementIcons[el.type] || (
                          <Box className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                      <div className="truncate text-slate-600">{el.label}</div>
                    </div>
                  ))}
                </div>

                {elements.length > 8 && (
                  <div className="text-center text-xs text-slate-400 mt-2">
                    +{elements.length - 8} 更多元素...
                  </div>
                )}
              </div>
            </div>

            <Separator className="my-4" />

            {/* Element Details */}
            <h4 className="font-medium text-sm mb-3">元素详情</h4>
            <div className="space-y-2">
              {elements.map((el: UIElement, idx: number) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-2.5 rounded-md border border-slate-100 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex-shrink-0">
                    {elementIcons[el.type] || (
                      <Box className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-slate-700">
                        {el.label}
                      </span>
                      <Badge variant="secondary" className="text-[10px] px-1.5">
                        {el.type}
                      </Badge>
                    </div>
                    {el.action && (
                      <p className="text-xs text-slate-400 mt-0.5 truncate">
                        交互：{el.action}
                      </p>
                    )}
                  </div>
                  <div className="text-xs text-slate-400 flex-shrink-0">
                    {el.position}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
