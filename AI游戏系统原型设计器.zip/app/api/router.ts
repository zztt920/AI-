import { createRouter, publicQuery } from "./middleware";
import { prototypeRouter } from "./routers/prototype";
import { aiRouter } from "./routers/ai";
import { validatorRouter } from "./routers/validator";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  prototype: prototypeRouter,
  ai: aiRouter,
  validator: validatorRouter,
});

export type AppRouter = typeof appRouter;
