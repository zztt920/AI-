import { createRouter, publicQuery } from "../middleware";
import { z } from "zod";
import { getDb } from "../queries/connection";
import { prototypes } from "../../db/schema";
import { eq, desc } from "drizzle-orm";

export const prototypeRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(prototypes).orderBy(desc(prototypes.createdAt));
  }),

  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }: { input: { id: number } }) => {
      const db = getDb();
      const results = await db
        .select()
        .from(prototypes)
        .where(eq(prototypes.id, input.id))
        .limit(1);
      return results[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        title: z.string().min(1).max(255),
        gameType: z.string().min(1).max(100),
        keywords: z.string().min(1).max(500),
      })
    )
    .mutation(async ({ input }: { input: { title: string; gameType: string; keywords: string } }) => {
      const db = getDb();
      const result = await db.insert(prototypes).values({
        title: input.title,
        gameType: input.gameType,
        keywords: input.keywords,
        status: "generating",
      });
      return { id: Number(result[0].insertId) };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["generating", "completed", "error"]).optional(),
        coreLogic: z.string().optional(),
        interactionFlow: z.string().optional(),
        numericalFramework: z.string().optional(),
        validationResult: z.string().optional(),
        flowchartMermaid: z.string().optional(),
        documentMarkdown: z.string().optional(),
        uiPrototype: z.any().optional(),
      })
    )
    .mutation(async ({ input }: { input: { id: number;[key: string]: unknown } }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db
        .update(prototypes)
        .set(data)
        .where(eq(prototypes.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }: { input: { id: number } }) => {
      const db = getDb();
      await db.delete(prototypes).where(eq(prototypes.id, input.id));
      return { success: true };
    }),
});
