import { createRouter, publicQuery } from "../middleware";
import { z } from "zod";

interface ModuleInput {
  name: string;
  description: string;
  inputs: string[];
  outputs: string[];
}

interface ValidationIssue {
  severity: "error" | "warning" | "info";
  module: string;
  description: string;
  suggestion: string;
}

export const validatorRouter = createRouter({
  validateSystem: publicQuery
    .input(
      z.object({
        coreLogic: z.string(),
        modules: z.array(
          z.object({
            name: z.string(),
            description: z.string(),
            inputs: z.array(z.string()),
            outputs: z.array(z.string()),
          })
        ),
        numericalFramework: z.string().optional(),
      })
    )
    .mutation(({ input }: { input: { coreLogic: string; modules: ModuleInput[]; numericalFramework?: string } }) => {
      const { modules, numericalFramework } = input;
      const issues: ValidationIssue[] = [];

      // 1. Check module dependency cycles
      modules.forEach((mod: ModuleInput) => {
        mod.inputs.forEach((inp: string) => {
          const isProduced = modules.some((m: ModuleInput) =>
            m.outputs.some((o: string) => o.includes(inp) || inp.includes(o))
          );
          if (!isProduced && inp !== "玩家输入" && inp !== "外部事件") {
            issues.push({
              severity: "warning",
              module: mod.name,
              description: `输入项 "${inp}" 没有明确的产出模块`,
              suggestion: `检查是否有模块负责产出 "${inp}"，或确认该输入为外部输入`,
            });
          }
        });
      });

      // Check for unconsumed outputs
      modules.forEach((mod: ModuleInput) => {
        mod.outputs.forEach((out: string) => {
          const isConsumed = modules.some((m: ModuleInput) =>
            m.inputs.some((i: string) => i.includes(out) || out.includes(i))
          );
          if (!isConsumed) {
            issues.push({
              severity: "info",
              module: mod.name,
              description: `产出项 "${out}" 没有被其他模块消费`,
              suggestion: `确认该产出是否为核心输出，或考虑减少不必要的产出`,
            });
          }
        });
      });

      // 2. Check balance indicators in numerical framework
      if (numericalFramework) {
        const hasGrowthCurve =
          numericalFramework.includes("成长") ||
          numericalFramework.includes("curve") ||
          numericalFramework.includes("growth");
        const hasEconomy =
          numericalFramework.includes("经济") ||
          numericalFramework.includes("economy");
        const hasBalance =
          numericalFramework.includes("平衡") ||
          numericalFramework.includes("balance");

        if (!hasGrowthCurve) {
          issues.push({
            severity: "warning",
            module: "数值系统",
            description: "数值框架中缺少成长曲线设计",
            suggestion: "添加玩家成长曲线，明确各阶段属性提升幅度",
          });
        }
        if (!hasEconomy) {
          issues.push({
            severity: "warning",
            module: "数值系统",
            description: "数值框架中缺少经济系统设计",
            suggestion: "添加货币循环、产出消耗比、通货膨胀控制机制",
          });
        }
        if (!hasBalance) {
          issues.push({
            severity: "info",
            module: "数值系统",
            description: "数值框架中缺少平衡性校验",
            suggestion: "添加不同职业/装备的DPS对比表，确保无绝对最优解",
          });
        }

        // Check for formula completeness
        const formulaRegex = /[=＝][\s]*[\d\w+\-*/().]+/g;
        const formulas = numericalFramework.match(formulaRegex) || [];
        if (formulas.length < 2) {
          issues.push({
            severity: "warning",
            module: "数值系统",
            description: "数值框架中的公式数量较少（<2个）",
            suggestion: "补充核心战斗公式、伤害计算公式、掉落概率公式等",
          });
        }
      }

      // 3. Check core logic completeness
      const hasErrorHandling =
        input.coreLogic.includes("异常") ||
        input.coreLogic.includes("错误") ||
        input.coreLogic.includes("边界") ||
        input.coreLogic.includes("edge case") ||
        input.coreLogic.includes("error");
      const hasStateManagement =
        input.coreLogic.includes("状态") ||
        input.coreLogic.includes("state") ||
        input.coreLogic.includes("machine");
      const hasDataFlow =
        input.coreLogic.includes("数据") ||
        input.coreLogic.includes("data") ||
        input.coreLogic.includes("接口");

      if (!hasErrorHandling) {
        issues.push({
          severity: "warning",
          module: "核心逻辑",
          description: "文档中缺少异常处理描述",
          suggestion: "添加网络中断、玩家离线、数据异常的兜底方案",
        });
      }
      if (!hasStateManagement) {
        issues.push({
          severity: "info",
          module: "核心逻辑",
          description: "文档中缺少状态机描述",
          suggestion: "建议用状态机描述核心玩法的状态转换关系",
        });
      }
      if (!hasDataFlow) {
        issues.push({
          severity: "info",
          module: "核心逻辑",
          description: "文档中缺少数据流描述",
          suggestion: "添加数据流向图，明确各模块间的数据传递关系",
        });
      }

      // 4. Check module count
      if (modules.length < 3) {
        issues.push({
          severity: "info",
          module: "系统架构",
          description: `系统模块数量较少（${modules.length}个）`,
          suggestion: "考虑是否需要拆分为更细粒度的子模块",
        });
      }
      if (modules.length > 15) {
        issues.push({
          severity: "warning",
          module: "系统架构",
          description: `系统模块数量较多（${modules.length}个）`,
          suggestion: "考虑合并高内聚模块，降低系统复杂度",
        });
      }

      // Determine overall status
      const errors = issues.filter((i) => i.severity === "error").length;
      const warnings = issues.filter((i) => i.severity === "warning").length;
      const overall: "pass" | "warning" | "fail" =
        errors > 0 ? "fail" : warnings > 2 ? "warning" : "pass";

      return {
        overall,
        issues,
        metrics: {
          totalModules: modules.length,
          issuesFound: issues.length,
          errors,
          warnings,
        },
      };
    }),
});
