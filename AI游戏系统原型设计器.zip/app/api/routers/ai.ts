import { createRouter, publicQuery } from "../middleware";
import { z } from "zod";
import { getDb } from "../queries/connection";
import { prototypes } from "../../db/schema";
import { eq } from "drizzle-orm";

interface AIMessage {
  role: string;
  content: string;
}

function getMockData(title: string, gameType: string, keywords: string) {
  const now = new Date().toISOString();
  const coreLogic = `# ${title} - 核心逻辑文档\n\n## 1. 系统概述\n\n本系统为**${gameType}**类型的游戏核心玩法系统，围绕「${keywords}」构建完整的游戏体验闭环。\n\n### 1.1 设计目标\n- 提供深度且易上手的${gameType}体验\n- 通过${keywords}构建核心循环，驱动玩家长期留存\n- 建立清晰的成长路径，让玩家在每个阶段都有明确目标\n\n### 1.2 系统定位\n| 维度 | 定位 |\n|------|------|\n| 核心循环 | 探索→收集→强化→验证 |\n| 单次时长 | 15-30分钟 |\n| 目标玩家 | ${gameType}核心玩家 |\n| 付费模式 | 外观付费+便利付费 |\n\n## 2. 核心循环\n\n\`\`\`\n[进入游戏] → [选择玩法] → [核心挑战] → [获取奖励] → [养成强化] → [验证成长] → [循环]\n              ↓                                              ↓\n         [新手引导]                                    [社交分享]\n\`\`\`\n\n### 2.1 循环说明\n1. **进入游戏**：玩家登录后进入主界面，展示当日目标和推荐玩法\n2. **选择玩法**：根据当前状态推荐适合的玩法内容\n3. **核心挑战**：执行${keywords}相关的核心玩法操作\n4. **获取奖励**：根据表现获得对应品质的奖励\n5. **养成强化**：使用奖励资源提升角色/装备/能力\n6. **验证成长**：通过下一场挑战验证养成效果\n\n## 3. 主要系统模块\n\n### 3.1 模块一览\n| 模块名称 | 职责 | 输入 | 输出 |\n|---------|------|------|------|\n| 账号系统 | 玩家身份管理 | 注册信息 | 玩家ID、Token |\n| 匹配系统 | 玩法匹配与组队 | 玩家等级、偏好 | 对局房间 |\n| 战斗系统 | 核心玩法执行 | 玩家操作指令 | 战斗结果 |\n| 奖励系统 | 战后结算与发放 | 战斗评分 | 道具、货币、经验 |\n| 养成系统 | 角色成长管理 | 消耗资源 | 属性提升 |\n| 背包系统 | 道具存储与管理 | 获取/消耗道具 | 道具状态变更 |\n| 社交系统 | 玩家间互动 | 好友请求、组队邀请 | 社交关系数据 |\n| 商城系统 | 付费内容展示与购买 | 付费请求 | 道具发放 |\n\n### 3.2 关键状态机\n\n**玩家状态机：**\n\`\`\`\n离线 → [登录] → 在线(大厅)\n在线(大厅) → [匹配] → 匹配中\n在线(大厅) → [打开养成] → 养成界面\n在线(大厅) → [打开背包] → 背包界面\n匹配中 → [匹配成功] → 战斗中\n匹配中 → [取消匹配] → 在线(大厅)\n战斗中 → [战斗结束] → 结算界面\n结算界面 → [返回大厅] → 在线(大厅)\n\`\`\`\n\n## 4. 数据结构\n\n### 4.1 核心数据表\n\`\`\`\nPlayer {\n  id: bigint PK\n  nickname: varchar(32)\n  level: int\n  exp: bigint\n  currency_gold: bigint\n  currency_gem: bigint\n  created_at: timestamp\n  last_login: timestamp\n}\n\nPlayerStats {\n  player_id: bigint FK\n  attack: int\n  defense: int\n  hp: int\n  speed: int\n  crit_rate: float\n}\n\nItem {\n  id: bigint PK\n  player_id: bigint FK\n  item_template_id: int\n  quantity: int\n  acquired_at: timestamp\n}\n\nBattleRecord {\n  id: bigint PK\n  player_id: bigint FK\n  battle_type: enum\n  result: enum [win, lose, draw]\n  score: int\n  duration: int\n  created_at: timestamp\n}\n\`\`\`\n\n## 5. 接口定义\n\n### 5.1 核心接口\n| 接口 | 方法 | 请求 | 响应 |\n|------|------|------|------|\n| /api/match/start | POST | {mode: string} | {room_id, players[]}|\n| /api/battle/action | POST | {action_type, target, params} | {result, state} |\n| /api/battle/end | POST | {room_id} | {result, rewards} |\n| /api/player/upgrade | POST | {item_id, cost} | {success, new_stats} |\n| /api/inventory/use | POST | {item_id, quantity} | {success, effect} |\n\n## 6. 边界情况处理\n\n### 6.1 网络中断\n- 战斗中网络中断：保留断线前状态，允许30秒内重连\n- 结算时网络中断：异步保存结算结果，玩家下次登录自动补发\n- 养成操作时网络中断：操作原子化，确保资源不丢失\n\n### 6.2 并发操作\n- 同时消耗同一道具：使用乐观锁，先检查库存再扣减\n- 同时升级同一属性：串行处理，后提交的请求基于最新状态\n\n### 6.3 异常输入\n- 非法参数：前端校验+后端二次校验，返回明确的错误码\n- 超时操作：设置操作超时时间（5秒），超时后自动回滚`;

  const interactionFlow = `# 交互流程文档\n\n## 1. 玩家操作流程\n\n### 1.1 首次进入流程\n\`\`\`\n[启动游戏] → [加载资源] → [展示Logo] → [登录界面]\n  → [新玩家] → [新手引导] → [首个关卡] → [引导结算] → [主界面]\n  → [老玩家] → [自动登录] → [主界面]\n\`\`\`\n\n### 1.2 核心玩法流程\n\`\`\`\n[主界面] → [点击开始] → [模式选择] → [匹配对手]\n  → [匹配成功] → [加载关卡] → [倒计时开始] → [核心玩法]\n  → [胜负判定] → [结算界面] → [奖励展示] → [返回主界面]\n\`\`\`\n\n### 1.3 养成操作流程\n\`\`\`\n[主界面] → [点击养成] → [选择养成类型] → [选择目标]\n  → [确认消耗] → [执行养成] → [播放动画] → [属性展示]\n  → [返回养成界面] 或 [返回主界面]\n\`\`\`\n\n## 2. 系统响应逻辑\n\n### 2.1 匹配系统响应\n| 玩家操作 | 系统响应 | 响应时间 |\n|---------|---------|---------|\n| 点击匹配 | 进入匹配队列，显示匹配中动画 | <100ms |\n| 匹配成功 | 展示对手信息，进入加载 | 1-3s |\n| 匹配超时 | 提示"匹配失败"，询问是否重试 | 30s |\n| 取消匹配 | 从队列移除，返回主界面 | <100ms |\n\n### 2.2 战斗系统响应\n| 玩家操作 | 系统响应 | 响应时间 |\n|---------|---------|---------|\n| 发送操作指令 | 校验合法性→执行→广播结果 | <50ms |\n| 断线重连 | 恢复断线前状态→继续战斗 | <500ms |\n| 战斗结束 | 计算评分→发放奖励→记录战绩 | <200ms |\n\n## 3. 界面跳转关系\n\n\`\`\`mermaid\ngraph LR\n  A[主界面] --> B[模式选择]\n  A --> C[养成界面]\n  A --> D[背包界面]\n  A --> E[社交界面]\n  A --> F[商城界面]\n  B --> G[匹配中]\n  G --> H[战斗界面]\n  H --> I[结算界面]\n  I --> A\n  C --> A\n  D --> A\n  E --> A\n  F --> A\n\`\`\`\n\n## 4. 异常流程处理\n\n### 4.1 网络异常\n- 弱网环境：操作队列缓存，网络恢复后批量提交\n- 完全断网：进入离线模式提示，保存本地状态\n\n### 4.2 操作异常\n- 快速连续点击：防重机制，忽略200ms内的重复操作\n- 资源不足操作：前置校验，操作前提示资源不足\n\n## 5. 并发操作处理\n- 同账号多端登录：后登录踢出先登录\n- 多操作同时进行：操作队列化，确保数据一致性`;

  const numericalFramework = `# 数值框架文档\n\n## 1. 数值体系总览\n\n本数值框架围绕「成长驱动+社交验证」构建，确保玩家在养成过程中能持续感受到成长反馈。\n\n## 2. 成长曲线设计\n\n### 2.1 等级经验表\n| 等级 | 所需经验 | 累计经验 | 升级奖励 |\n|------|---------|---------|---------|\n| 1→2 | 100 | 100 | 100金币+新手包 |\n| 2→5 | 200 | 700 | 解锁新玩法 |\n| 5→10 | 500 | 3200 | 稀有道具箱×3 |\n| 10→20 | 1,500 | 18,200 | 专属称号 |\n| 20→30 | 5,000 | 68,200 | 传说级装备 |\n| 30→50 | 15,000 | 368,200 | 限定外观 |\n| 50→100 | 50,000 | 2,618,200 | 至尊称号 |\n\n### 2.2 属性成长公式\n\`\`\`\n基础属性 = 等级基数 × 职业系数 × (1 + 养成加成)\n\n其中：\n- 等级基数 = 10 + (等级-1) × 5\n- 职业系数 = 攻击型1.2 / 防御型0.8 / 均衡型1.0\n- 养成加成 = Σ(装备加成 + 技能加成 + 天赋加成)\n\`\`\`\n\n## 3. 经济系统数值\n\n### 3.1 货币体系\n| 货币类型 | 获取方式 | 消耗场景 | 日产出上限 |\n|---------|---------|---------|-----------|\n| 金币 | 战斗奖励、任务 | 基础养成 | 50,000 |\n| 钻石 | 充值、成就 | 高级抽卡 | 500（免费） |\n| 友情点 | 好友互动 | 友情抽卡 | 1,000 |\n\n### 3.2 产出消耗比\n\`\`\`\n日总产出 ≈ 日基础消耗 × 1.3\n\n设计意图：\n- 让轻度玩家（日活跃30分钟）能维持基本养成\n- 让重度玩家（日活跃3小时）有30%盈余用于储备\n\`\`\`\n\n## 4. 战斗公式设计\n\n### 4.1 伤害公式\n\`\`\`\n实际伤害 = (攻击力 × 技能倍率 - 防御力 × 0.5) × 暴击系数 × 随机系数\n\n暴击系数 = 暴击时2.0，未暴击时1.0\n随机系数 = 0.95 ~ 1.05（均匀分布）\n\`\`\`\n\n### 4.2 战力计算公式\n\`\`\`\n战力 = 攻击×3 + 防御×2 + HP×0.5 + 速度×1.5 + 暴击率×100\n\`\`\`\n\n## 5. 概率与随机\n\n### 5.1 抽卡概率\n| 品质 | 概率 | 保底机制 |\n|------|------|---------|\n| N（普通） | 60% | 无 |\n| R（稀有） | 25% | 10抽必出R+ |\n| SR（超稀有） | 12% | 50抽必出SR |\n| SSR（传说） | 3% | 100抽必出SSR |\n\n### 5.2 掉落概率\n\`\`\`\n基础掉率 = 关卡基准 × 难度系数 × 幸运加成\n\n幸运加成 = 1 + (幸运值 × 0.001)\n\`\`\`\n\n## 6. 平衡性校验表\n\n| 校验项 | 设计值 | 允许范围 | 状态 |\n|-------|-------|---------|------|\n| 新手→满级天数 | 90天 | 60-120天 | ✅ |\n| 日活跃时长 | 45分钟 | 30-90分钟 | ✅ |\n| 付费转化率 | 5% | 3-8% | ✅ |\n| 7日留存率 | 35% | 25-40% | ✅ |\n| ARPDAU | ¥0.5 | ¥0.3-¥1.0 | ✅ |`;

  const flowchartMermaid = `flowchart TD\n    Start([开始]) --> Login{是否已登录?}\n    Login -->|否| Register[注册/登录] --> Tutorial\n    Login -->|是| Main[进入主界面]\n    \n    subgraph 新手引导\n        Tutorial[新手引导] --> FirstBattle[首场战斗]\n        FirstBattle --> FirstReward[引导奖励]\n    end\n    \n    FirstReward --> Main\n    Main --> ModeSelect{选择玩法}\n    \n    ModeSelect -->|PVE| MatchStart[开始匹配关卡]\n    ModeSelect -->|PVP| MatchPVP[匹配对手]\n    ModeSelect -->|养成| Upgrade[进入养成界面]\n    ModeSelect -->|背包| Inventory[打开背包]\n    \n    subgraph 战斗流程\n        MatchStart --> LoadLevel[加载关卡]\n        MatchPVP --> LoadLevel\n        LoadLevel --> Countdown[3秒倒计时]\n        Countdown --> Battle[战斗中]\n        Battle --> CheckEnd{战斗结束?}\n        CheckEnd -->|否| Battle\n        CheckEnd -->|是| Calculate[计算评分]\n    end\n    \n    Calculate --> Settlement[结算界面]\n    Settlement --> Reward[发放奖励]\n    Reward --> BackMain[返回主界面]\n    \n    Upgrade --> Consume{资源充足?}\n    Consume -->|是| DoUpgrade[执行养成]\n    Consume -->|否| Insufficient[提示资源不足]\n    DoUpgrade --> ShowStats[展示新属性]\n    ShowStats --> Main\n    Insufficient --> Main\n    \n    Inventory --> UseItem{使用道具?}\n    UseItem -->|是| ApplyEffect[应用效果]\n    UseItem -->|否| Main\n    ApplyEffect --> Main\n    \n    subgraph 异常处理\n        Battle --> Disconnect{网络中断?}\n        Disconnect -->|是| SaveState[保存状态]\n        SaveState --> Reconnect{30秒内重连?}\n        Reconnect -->|是| Restore[恢复状态]\n        Reconnect -->|否| GiveUp[判定放弃]\n        Restore --> Battle\n        GiveUp --> Settlement\n    end`;

  const uiPrototype = {
    screens: [
      {
        name: "登录界面",
        description: "玩家首次进入游戏的登录/注册界面",
        elements: [
          { type: "image", label: "游戏Logo", position: "center", action: "展示品牌" },
          { type: "input", label: "账号输入", position: "center", action: "输入账号" },
          { type: "input", label: "密码输入", position: "center", action: "输入密码" },
          { type: "button", label: "登录按钮", position: "center", action: "执行登录" },
          { type: "button", label: "游客登录", position: "center", action: "快速体验" },
          { type: "label", label: "版本号", position: "bottom-center", action: "展示版本" },
        ],
      },
      {
        name: "主界面",
        description: "游戏核心枢纽，展示玩家信息和主要功能入口",
        elements: [
          { type: "panel", label: "玩家信息栏", position: "top-left", action: "展示头像/等级/战力" },
          { type: "label", label: "金币数量", position: "top-right", action: "展示货币" },
          { type: "label", label: "钻石数量", position: "top-right", action: "展示货币" },
          { type: "button", label: "开始战斗", position: "center", action: "进入模式选择" },
          { type: "button", label: "角色养成", position: "bottom-left", action: "进入养成界面" },
          { type: "button", label: "背包", position: "bottom-left", action: "打开背包" },
          { type: "button", label: "社交", position: "bottom-center", action: "打开好友列表" },
          { type: "button", label: "商城", position: "bottom-right", action: "打开商城" },
          { type: "button", label: "设置", position: "top-right", action: "打开设置" },
          { type: "panel", label: "活动公告", position: "center", action: "展示活动信息" },
        ],
      },
      {
        name: "模式选择界面",
        description: "选择不同的游戏模式",
        elements: [
          { type: "button", label: "剧情模式", position: "center", action: "进入关卡选择" },
          { type: "button", label: "竞技场", position: "center", action: "PVP匹配" },
          { type: "button", label: "挑战模式", position: "center", action: "高难度挑战" },
          { type: "button", label: "每日任务", position: "center", action: "查看每日目标" },
          { type: "button", label: "返回", position: "top-left", action: "返回主界面" },
        ],
      },
      {
        name: "匹配中界面",
        description: "展示匹配进度和动画",
        elements: [
          { type: "label", label: "匹配中...", position: "center", action: "展示匹配状态" },
          { type: "progress", label: "匹配进度条", position: "center", action: "展示匹配进度" },
          { type: "label", label: "预计时间", position: "center", action: "展示预计等待时间" },
          { type: "button", label: "取消匹配", position: "bottom-center", action: "取消匹配返回" },
        ],
      },
      {
        name: "战斗界面",
        description: "核心战斗场景",
        elements: [
          { type: "panel", label: "敌方信息", position: "top-center", action: "展示敌人血条/名称" },
          { type: "panel", label: "己方信息", position: "bottom-left", action: "展示己方血条/技能" },
          { type: "button", label: "技能A", position: "bottom-right", action: "释放技能1" },
          { type: "button", label: "技能B", position: "bottom-right", action: "释放技能2" },
          { type: "button", label: "技能C", position: "bottom-right", action: "释放大招" },
          { type: "button", label: "普攻", position: "bottom-center", action: "普通攻击" },
          { type: "button", label: "暂停", position: "top-right", action: "暂停游戏" },
          { type: "label", label: "战斗计时", position: "top-left", action: "展示战斗用时" },
        ],
      },
      {
        name: "结算界面",
        description: "战斗结束后展示结果和奖励",
        elements: [
          { type: "label", label: "胜负结果", position: "top-center", action: "展示胜利/失败" },
          { type: "label", label: "获得经验", position: "center", action: "展示经验值" },
          { type: "label", label: "获得金币", position: "center", action: "展示金币数" },
          { type: "panel", label: "掉落道具", position: "center", action: "展示战利品" },
          { type: "label", label: "战斗统计", position: "center", action: "展示伤害/承伤等数据" },
          { type: "button", label: "再玩一局", position: "bottom-left", action: "快速重开" },
          { type: "button", label: "返回大厅", position: "bottom-right", action: "返回主界面" },
        ],
      },
      {
        name: "养成界面",
        description: "角色能力提升和装备管理",
        elements: [
          { type: "panel", label: "角色立绘", position: "left", action: "展示角色形象" },
          { type: "panel", label: "属性面板", position: "center", action: "展示当前属性" },
          { type: "button", label: "升级", position: "center", action: "消耗经验升级" },
          { type: "button", label: "装备", position: "center", action: "进入装备管理" },
          { type: "button", label: "技能", position: "center", action: "进入技能树" },
          { type: "button", label: "返回", position: "top-left", action: "返回主界面" },
        ],
      },
      {
        name: "背包界面",
        description: "道具查看和使用",
        elements: [
          { type: "list", label: "道具列表", position: "center", action: "展示所有道具" },
          { type: "panel", label: "道具详情", position: "right", action: "展示选中道具信息" },
          { type: "button", label: "使用", position: "right", action: "使用选中道具" },
          { type: "button", label: "出售", position: "right", action: "出售道具换金币" },
          { type: "button", label: "筛选全部", position: "top-center", action: "筛选道具类型" },
          { type: "button", label: "筛选装备", position: "top-center", action: "筛选道具类型" },
          { type: "button", label: "筛选消耗品", position: "top-center", action: "筛选道具类型" },
          { type: "button", label: "返回", position: "top-left", action: "返回主界面" },
        ],
      },
      {
        name: "商城界面",
        description: "付费内容和道具购买",
        elements: [
          { type: "list", label: "商品列表", position: "center", action: "展示可购买商品" },
          { type: "panel", label: "商品详情", position: "right", action: "展示商品信息" },
          { type: "button", label: "购买", position: "right", action: "执行购买流程" },
          { type: "label", label: "当前钻石", position: "top-right", action: "展示余额" },
          { type: "button", label: "充值", position: "top-right", action: "进入充值流程" },
          { type: "button", label: "返回", position: "top-left", action: "返回主界面" },
        ],
      },
    ],
  };

  const validationResult = `# 逻辑校验报告\n\n## 校验概述\n\n**整体评价：通过（存在3个警告）**\n\n本系统设计整体逻辑清晰，核心循环完整，模块间依赖关系合理。共发现3个警告级别的潜在问题，建议在后续迭代中关注。\n\n---\n\n## 发现的问题\n\n| 严重度 | 模块 | 问题描述 | 建议修复方案 |\n|--------|------|---------|-------------|\n| 警告 | 经济系统 | 日产出上限（50,000金币）与基础消耗比例未经实际验证 | 建议通过小规模AB测试验证数值体验 |\n| 警告 | 战斗系统 | 断线重连30秒窗口期可能过长，存在被恶意利用的风险 | 考虑缩短至15秒，或增加断线惩罚机制 |\n| 警告 | 抽卡系统 | SSR 3%的爆率在当前市场环境下偏低 | 建议首SSR保底降至50抽，提升新手体验 |\n| 信息 | 养成系统 | 属性成长公式中职业系数差异较大（0.8~1.2） | 确保PVP中有平衡机制弥补属性差距 |\n\n---\n\n## 数值平衡检查\n\n| 检查项 | 设计值 | 行业标准 | 评估 |\n|-------|-------|---------|------|\n| 成长周期 | 90天满级 | 60-120天 | ✅ 合理 |\n| 日货币产出 | 50,000金币 | 依游戏类型而定 | ⚠️ 需验证 |\n| 抽卡保底 | 100抽SSR | 80-120抽 | ✅ 合理 |\n| PVE难度曲线 | 线性+阶梯 | 非线性成长 | ✅ 合理 |\n| 付费深度 | ¥0.5 ARPDAU | ¥0.3-¥1.0 | ✅ 合理 |\n\n---\n\n## 边界情况评估\n\n| 场景 | 处理方案 | 评估 |\n|------|---------|------|\n| 网络中断（战斗中） | 30秒重连窗口+状态保存 | ✅ 完善 |\n| 资源不足操作 | 前置校验+友好提示 | ✅ 完善 |\n| 同账号多端登录 | 后登录踢出先登录 | ✅ 合理 |\n| 快速连续点击 | 200ms防重机制 | ✅ 完善 |\n| 数据库异常 | 未明确描述 | ⚠️ 需补充 |\n\n---\n\n## 优化建议\n\n1. **增加离线收益机制**：让无法每日登录的玩家也能保持一定进度\n2. **完善数据库容灾方案**：补充主从切换和数据备份策略\n3. **考虑赛季制设计**：90天满级后建议引入赛季重置或无限成长机制\n4. **增加社交验证反馈**：在养成系统中加入"战力排行榜"等社交对比元素`;

  return {
    coreLogic,
    interactionFlow,
    numericalFramework,
    validationResult,
    flowchartMermaid,
    uiPrototype,
    documentMarkdown: `# ${title} - 游戏系统设计文档\n\n## 1. 核心逻辑\n\n${coreLogic}\n\n---\n\n## 2. 交互流程\n\n${interactionFlow}\n\n---\n\n## 3. 数值框架\n\n${numericalFramework}\n\n---\n\n## 4. 逻辑校验\n\n${validationResult}`,
  };
}

async function callAI(messages: AIMessage[], _temperature = 0.7): Promise<string> {
  const apiKey = process.env.KIMI_API_KEY;
  const baseUrl = "https://api.moonshot.cn/v1";
  const model = "kimi-latest";

  if (!apiKey) {
    throw new Error("No KIMI_API_KEY configured");
  }

  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
      temperature: _temperature,
      stream: false,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`AI API error: ${error}`);
  }

  const data = await response.json() as { choices: Array<{ message: { content: string } }> };
  return data.choices[0].message.content;
}

export const aiRouter = createRouter({
  generatePrototype: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string(),
        gameType: z.string(),
        keywords: z.string(),
        requirements: z.string().optional(),
      })
    )
    .mutation(async ({ input }: { input: { id: number; title: string; gameType: string; keywords: string; requirements?: string } }) => {
      const db = getDb();
      const { id, title, gameType, keywords } = input;

      // Check if API key is available
      const hasApiKey = !!process.env.KIMI_API_KEY;

      try {
        let coreLogic: string;
        let interactionFlow: string;
        let numericalFramework: string;
        let validationResult: string;
        let flowchartMermaid: string;
        let uiPrototype: Record<string, unknown>;
        let documentMarkdown: string;

        if (!hasApiKey) {
          // Use mock data for demo
          const mock = getMockData(title, gameType, keywords);
          coreLogic = mock.coreLogic;
          interactionFlow = mock.interactionFlow;
          numericalFramework = mock.numericalFramework;
          validationResult = mock.validationResult;
          flowchartMermaid = mock.flowchartMermaid;
          uiPrototype = mock.uiPrototype as Record<string, unknown>;
          documentMarkdown = mock.documentMarkdown;
        } else {
          // Real AI generation - Step 1: Core Logic
          coreLogic = await callAI([
            {
              role: "system",
              content: `你是一位资深游戏系统策划，擅长撰写游戏系统设计文档（功能设计文档FD）。\n请根据用户输入的游戏类型和关键词，生成一份完整的游戏系统核心逻辑文档。\n输出格式为Markdown，包含以下部分：\n1. 系统概述（System Overview）\n2. 核心循环（Core Loop）\n3. 主要系统模块（Main System Modules）\n4. 数据结构（Data Architecture）\n5. 接口定义（Interface Definitions）\n6. 边界情况处理（Edge Cases）`,
            },
            {
              role: "user",
              content: `请为以下游戏设计生成核心逻辑文档：\n游戏名称/主题：${title}\n游戏类型：${gameType}\n核心关键词：${keywords}\n${input.requirements ? `补充需求：${input.requirements}` : ""}`,
            },
          ]);

          await db
            .update(prototypes)
            .set({ coreLogic, status: "generating" })
            .where(eq(prototypes.id, id));

          // Step 2: Interaction Flow
          interactionFlow = await callAI([
            {
              role: "system",
              content: `你是一位游戏交互设计师。请根据已生成的核心逻辑，设计详细的交互流程。\n输出格式为Markdown，包含：\n1. 玩家操作流程（Player Operation Flow）\n2. 系统响应逻辑（System Response Logic）\n3. 界面跳转关系（Screen Transition Map）\n4. 异常流程处理（Error Handling Flow）\n5. 并发操作处理（Concurrency Handling）`,
            },
            {
              role: "user",
              content: `基于以下核心逻辑，生成交互流程文档：\n游戏类型：${gameType}\n${coreLogic.substring(0, 2000)}`,
            },
          ]);

          await db
            .update(prototypes)
            .set({ interactionFlow })
            .where(eq(prototypes.id, id));

          // Step 3: Numerical Framework
          numericalFramework = await callAI([
            {
              role: "system",
              content: `你是一位游戏数值策划。请设计游戏的数值框架。\n输出格式为Markdown，包含：\n1. 数值体系总览（Numerical System Overview）\n2. 成长曲线设计（Growth Curve）\n3. 经济系统数值（Economy Numbers）\n4. 战斗公式设计（Combat Formulas）\n5. 概率与随机（Probability & RNG）\n6. 平衡性校验表（Balance Check Table）`,
            },
            {
              role: "user",
              content: `基于以下信息，设计数值框架：\n游戏类型：${gameType}\n核心关键词：${keywords}\n${coreLogic.substring(0, 1500)}`,
            },
          ]);

          await db
            .update(prototypes)
            .set({ numericalFramework })
            .where(eq(prototypes.id, id));

          // Step 4: Flowchart
          const flowchartResponse = await callAI([
            {
              role: "system",
              content: `你是一位游戏系统设计师。请根据已生成的系统逻辑，生成Mermaid流程图代码。\n要求：\n1. 使用flowchart TD（从上到下）格式\n2. 包含开始/结束节点\n3. 包含判断节点（用菱形{}表示）\n4. 包含处理节点（用矩形[]表示）\n5. 包含子流程（用子图subgraph表示）\n6. 确保语法正确，可以被Mermaid渲染\n只输出Mermaid代码，不要输出Markdown代码块标记。`,
            },
            {
              role: "user",
              content: `基于以下核心逻辑和交互流程，生成系统流程图：\n游戏类型：${gameType}\n${coreLogic.substring(0, 1500)}\n${interactionFlow.substring(0, 1000)}`,
            },
          ]);

          flowchartMermaid = flowchartResponse
            .replace(/```mermaid\n?/g, "")
            .replace(/```\n?/g, "")
            .trim();

          await db
            .update(prototypes)
            .set({ flowchartMermaid })
            .where(eq(prototypes.id, id));

          // Step 5: UI Prototype
          const uiResponse = await callAI([
            {
              role: "system",
              content: `你是一位游戏UI设计师。请生成游戏界面原型描述。\n输出JSON格式（不要包含Markdown标记），结构如下：\n{"screens": [{"name": "界面名称","description": "界面功能描述","elements": [{"type": "button|label|input|list|panel|icon|progress", "label": "显示文本", "position": "top-left|top-center|top-right|center|bottom-left|bottom-center|bottom-right", "action": "点击行为描述"}]}]}\n请生成8-12个核心界面的原型描述。只输出JSON，不要其他内容。`,
            },
            {
              role: "user",
              content: `基于以下信息，生成UI原型：\n游戏类型：${gameType}\n${coreLogic.substring(0, 1500)}\n${interactionFlow.substring(0, 1000)}`,
            },
          ]);

          try {
            const cleaned = uiResponse
              .replace(/```json\n?/g, "")
              .replace(/```\n?/g, "")
              .trim();
            uiPrototype = JSON.parse(cleaned) as Record<string, unknown>;
          } catch {
            uiPrototype = { screens: [] };
          }

          // Step 6: Validation
          validationResult = await callAI([
            {
              role: "system",
              content: `你是一位游戏系统评审专家。请对以下系统设计进行逻辑校验。\n输出Markdown格式：\n## 校验概述\n## 发现的问题\n| 严重度 | 模块 | 问题描述 | 建议修复方案 |\n## 数值平衡检查\n## 边界情况评估\n## 优化建议`,
            },
            {
              role: "user",
              content: `请校验以下系统设计：\n游戏类型：${gameType}\n核心逻辑：${coreLogic.substring(0, 1500)}\n数值框架：${numericalFramework.substring(0, 1500)}`,
            },
          ]);

          documentMarkdown = `# ${title} - 游戏系统设计文档\n\n## 1. 核心逻辑\n\n${coreLogic}\n\n---\n\n## 2. 交互流程\n\n${interactionFlow}\n\n---\n\n## 3. 数值框架\n\n${numericalFramework}\n\n---\n\n## 4. 逻辑校验\n\n${validationResult}`;
        }

        // Save all data
        await db
          .update(prototypes)
          .set({
            coreLogic,
            interactionFlow,
            numericalFramework,
            validationResult,
            flowchartMermaid,
            uiPrototype,
            status: "completed",
            documentMarkdown,
          })
          .where(eq(prototypes.id, id));

        return {
          success: true,
          coreLogic,
          interactionFlow,
          numericalFramework,
          validationResult,
          flowchartMermaid,
          uiPrototype,
          isMock: !hasApiKey,
        };
      } catch (error) {
        await db
          .update(prototypes)
          .set({
            status: "error",
            validationResult: `生成失败: ${error instanceof Error ? error.message : "未知错误"}`,
          })
          .where(eq(prototypes.id, id));

        throw error;
      }
    }),
});
