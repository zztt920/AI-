export interface ParsedRequirement {
  gameType: string;
  coreMechanics: string[];
  targetPlayers: string;
  gameLoop: string;
  keyFeatures: string[];
}

export interface SystemModule {
  name: string;
  description: string;
  inputs: string[];
  outputs: string[];
  dependencies: string[];
  states: string[];
  transitions: StateTransition[];
}

export interface StateTransition {
  from: string;
  to: string;
  trigger: string;
  condition?: string;
}

export interface ValidationIssue {
  severity: "error" | "warning" | "info";
  module: string;
  description: string;
  suggestion: string;
}

export interface ValidationResult {
  overall: "pass" | "warning" | "fail";
  issues: ValidationIssue[];
  metrics: {
    totalModules: number;
    issuesFound: number;
    errors: number;
    warnings: number;
  };
}

export interface FlowchartNode {
  id: string;
  label: string;
  type: "start" | "process" | "decision" | "end" | "subprocess";
}

export interface FlowchartEdge {
  from: string;
  to: string;
  label?: string;
}

export interface UIPrototypeScreen {
  name: string;
  description: string;
  elements: UIElement[];
}

export interface UIElement {
  type: string;
  label: string;
  position: string;
  action?: string;
}

export interface GeneratedPrototype {
  title: string;
  gameType: string;
  coreLogic: string;
  interactionFlow: string;
  numericalFramework: string;
  modules: SystemModule[];
  validation: ValidationResult;
  flowchartMermaid: string;
  uiScreens: UIPrototypeScreen[];
}
